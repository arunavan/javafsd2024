package com.training.day7;
//overriding, method name, signature is same, dynamic, runtime 
class A{
	void sq(int s) {
		System.out.println("area:"+(s*s));
	}
}
class B extends A{
	@Override
	void sq(int s) {
		System.out.println("perimeter:"+(4*s));
	}
}
public class MOverride {
	public static void main(String[] args) {
		A a=new A();
		a.sq(5);
		a=new B();
		a.sq(5);
	}
}
